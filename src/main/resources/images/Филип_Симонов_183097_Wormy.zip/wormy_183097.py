# Wormy (a Nibbles clone)
# By Al Sweigart al@inventwithpython.com
# http://inventwithpython.com/pygame
# Released under a "Simplified BSD" license

import random, pygame, sys
import time

from pygame.locals import *


FPS = 15
WINDOWWIDTH = 640
WINDOWHEIGHT = 480
CELLSIZE = 20
assert WINDOWWIDTH % CELLSIZE == 0, "Window width must be a multiple of cell size."
assert WINDOWHEIGHT % CELLSIZE == 0, "Window height must be a multiple of cell size."
CELLWIDTH = int(WINDOWWIDTH / CELLSIZE)
CELLHEIGHT = int(WINDOWHEIGHT / CELLSIZE)


#             R    G    B
WHITE     = (255, 255, 255)
BLACK     = (  0,   0,   0)
RED       = (255,   0,   0)
GREEN     = (  0, 255,   0)
DARKGREEN = (  0, 155,   0)
DARKGRAY  = ( 40,  40,  40)
YELLOW    =  (255, 255, 0)

BGCOLOR = BLACK

UP = 'up'
DOWN = 'down'
LEFT = 'left'
RIGHT = 'right'

HEAD = 0 # syntactic sugar: index of the worm's head
NEW_WORM_TIMER = pygame.USEREVENT + 1 #REQUIREMENT: 1
FLAG = False

def main():
    global FPSCLOCK, DISPLAYSURF, BASICFONT, NEW_WORM_TIMER, FLAG
    pygame.init()
    pygame.time.set_timer(NEW_WORM_TIMER, 20000)     # REQUIREMENT: 1

    FPSCLOCK = pygame.time.Clock()
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
    BASICFONT = pygame.font.Font('freesansbold.ttf', 18)
    pygame.display.set_caption('Wormy')

    showStartScreen()
    while True:
        runGame()
        showGameOverScreen()


def runGame():
    global FLAG
    # Set a random start point.
    startx = random.randint(5, CELLWIDTH - 6)
    starty = random.randint(5, CELLHEIGHT - 6)
    additional_points=0
    wormCoords = [{'x': startx,     'y': starty},
                  {'x': startx - 1, 'y': starty},
                  {'x': startx - 2, 'y': starty}]


    # REQUIREMENT: 1
    whiteWormCoords = [{'x': startx,     'y': starty},
                  {'x': startx - 1, 'y': starty},
                  {'x': startx - 2, 'y': starty}]


    direction = RIGHT

    # REQUIREMENT: 1
    whiteWormDirection = UP
    start_time = time.time()
    new_worm_added = False
    second_worm = getRandomLocation()

    blink1_start_time = None
    blink2_start_time = None
    blink1_duration = 5  # seconds
    blink2_duration = 7  # seconds
    blink1_position = getRandomLocation()
    blink2_position = getRandomLocation()
    blink1_active = False
    blink2_active = False
    # Start the apple in a random place.
    apple = getRandomLocation()
    blink2_flag = False

    while True: # main game loop

        whiteFlag = False
        current_time = time.time()

        if current_time - start_time >= 5 and not blink1_active:
            blink1_position = getRandomLocation()
            blink1_start_time = current_time
            blink1_active = True

        #if current_time - start_time >= 7 and not blink2_active:
          #  blink2_position = getRandomLocation()
          #  blink2_start_time = current_time
           # blink2_active = True
        if not blink2_active and not blink2_flag and current_time - start_time >= 7:
            blink2_position = getRandomLocation()
            blink2_start_time = current_time
            blink2_active = True
            blink2_flag = True  # Set flag to prevent further appearances

        if blink1_active and current_time - blink1_start_time >= blink1_duration:
            blink1_active = False

        if blink2_active and current_time - blink2_start_time >= blink2_duration:
            blink2_active = False

        # Draw the blinking elements if they are active
        if blink1_active:
            drawBlinkingElement(blink1_position)
        if blink2_active:
            drawBlinkingElement(blink2_position)


        for event in pygame.event.get(): # event handling loop
            if event.type == NEW_WORM_TIMER:
                FLAG = True
                pygame.time.set_timer(NEW_WORM_TIMER, 20000)  #setting timer

            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:

                if (event.key == K_LEFT or event.key == K_a) and direction != RIGHT:
                    direction = LEFT
                elif (event.key == K_RIGHT or event.key == K_d) and direction != LEFT:
                    direction = RIGHT
                elif (event.key == K_UP or event.key == K_w) and direction != DOWN:
                    direction = UP
                elif (event.key == K_DOWN or event.key == K_s) and direction != UP:
                    direction = DOWN
                elif event.key == K_ESCAPE:
                    terminate()
                whiteWormDirection = random.choice((UP,DOWN,LEFT,RIGHT))

        # check if the worm has hit itself or the edge
        if wormCoords[HEAD]['x'] == -1 or wormCoords[HEAD]['x'] == CELLWIDTH or wormCoords[HEAD]['y'] == -1 or wormCoords[HEAD]['y'] == CELLHEIGHT:
            return # game over
        for wormBody in wormCoords[1:]:
            if wormBody['x'] == wormCoords[HEAD]['x'] and wormBody['y'] == wormCoords[HEAD]['y']:
                return # game over
            if wormBody['x'] == whiteWormCoords[HEAD]['x'] and wormBody['y'] == whiteWormCoords[HEAD]['y']:
                whiteFlag = True

        # check if worm has eaten an apple
        if wormCoords[HEAD]['x'] == apple['x'] and wormCoords[HEAD]['y'] == apple['y']:
            # don't remove worm's tail segment
            apple = getRandomLocation() # set a new apple somewhere
        else:
            del wormCoords[-1] # remove worm's tail segment

        if blink1_active and wormCoords[HEAD] == blink1_position:
            blink1_active = False
            drawBlinkingElement(blink1_position)  # Draw again to clear the blinking element
            additional_points += 3

        if blink2_active and wormCoords[HEAD] == blink2_position:
            blink2_active = False
            drawBlinkingElement(blink2_position)  # Draw again to clear the blinking element
            additional_points += 3

        # move the worm by adding a segment in the direction it is moving
        if direction == UP:
            newHead = {'x': wormCoords[HEAD]['x'], 'y': wormCoords[HEAD]['y'] - 1}
        elif direction == DOWN:
            newHead = {'x': wormCoords[HEAD]['x'], 'y': wormCoords[HEAD]['y'] + 1}
        elif direction == LEFT:
            newHead = {'x': wormCoords[HEAD]['x'] - 1, 'y': wormCoords[HEAD]['y']}
        elif direction == RIGHT:
            newHead = {'x': wormCoords[HEAD]['x'] + 1, 'y': wormCoords[HEAD]['y']}

        # REQUIREMENT: 1
        if whiteWormCoords[HEAD]['x'] == 0:
            whiteWormDirection = RIGHT
        elif whiteWormCoords[HEAD]['x'] == CELLWIDTH - 1:
            whiteWormDirection = LEFT
        elif whiteWormCoords[HEAD]['y'] == 0:
            whiteWormDirection = DOWN
        elif whiteWormCoords[HEAD]['y'] == CELLHEIGHT - 1:
            whiteWormDirection = UP

        # REQUIREMENT: 1
        if whiteWormDirection == UP:
            whiteNewHead= {'x': whiteWormCoords[HEAD]['x'], 'y': whiteWormCoords[HEAD]['y'] - 1}
        elif whiteWormDirection == DOWN:
            whiteNewHead = {'x': whiteWormCoords[HEAD]['x'], 'y': whiteWormCoords[HEAD]['y'] + 1}
        elif whiteWormDirection == LEFT:
            whiteNewHead = {'x': whiteWormCoords[HEAD]['x'] - 1, 'y': whiteWormCoords[HEAD]['y']}
        elif whiteWormDirection == RIGHT:
            whiteNewHead = {'x': whiteWormCoords[HEAD]['x'] + 1, 'y': whiteWormCoords[HEAD]['y']}
        #REQUIREMENT: 1
        if not whiteFlag:
            del whiteWormCoords[-1]

        whiteWormCoords.insert(0, whiteNewHead)

        wormCoords.insert(0, newHead)
        DISPLAYSURF.fill(BGCOLOR)
        drawGrid()
        drawWorm(wormCoords, GREEN)

        # REQUIREMENT: 2
        if FLAG:
            drawWorm(whiteWormCoords, WHITE)
            drawBlinkingElement(blink1_position)
            if(blink2_flag is False):
                drawBlinkingElement(blink2_position)


        drawApple(apple, RED)
        drawScore(len(wormCoords) - 3,additional_points)
        pygame.display.update()
        FPSCLOCK.tick(FPS)

def drawPressKeyMsg():
    pressKeySurf = BASICFONT.render('Press a key to play.', True, DARKGRAY)
    pressKeyRect = pressKeySurf.get_rect()
    pressKeyRect.topleft = (WINDOWWIDTH - 200, WINDOWHEIGHT - 30)
    DISPLAYSURF.blit(pressKeySurf, pressKeyRect)


def makeText(text, color, bgcolor, top, left):
    # create the Surface and Rect objects for some text.
    textSurf = BASICFONT.render(text, True, color, bgcolor)
    textRect = textSurf.get_rect()
    textRect.topleft = (top, left)
    return (textSurf, textRect)


def checkForKeyPress():
    if len(pygame.event.get(QUIT)) > 0:
        terminate()

    keyUpEvents = pygame.event.get(KEYUP)
    if len(keyUpEvents) == 0:
        return None
    if keyUpEvents[0].key == K_ESCAPE:
        terminate()
    return keyUpEvents[0].key


def showStartScreen():
    titleFont = pygame.font.Font('freesansbold.ttf', 100)
    titleSurf1 = titleFont.render('Wormy!', True, WHITE, DARKGREEN)
    titleSurf2 = titleFont.render('Wormy!', True, GREEN)

    degrees1 = 0
    degrees2 = 0
    while True:
        DISPLAYSURF.fill(BGCOLOR)
        rotatedSurf1 = pygame.transform.rotate(titleSurf1, degrees1)
        rotatedRect1 = rotatedSurf1.get_rect()
        rotatedRect1.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf1, rotatedRect1)

        rotatedSurf2 = pygame.transform.rotate(titleSurf2, degrees2)
        rotatedRect2 = rotatedSurf2.get_rect()
        rotatedRect2.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf2, rotatedRect2)

        drawPressKeyMsg()

        if checkForKeyPress():
            pygame.event.get() # clear event queue
            return
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        degrees1 += 3 # rotate by 3 degrees each frame
        degrees2 += 7 # rotate by 7 degrees each frame


def terminate():
    pygame.quit()
    sys.exit()


def getRandomLocation():
    return {'x': random.randint(0, CELLWIDTH - 1), 'y': random.randint(0, CELLHEIGHT - 1)}


def showGameOverScreen():
    global FLAG
    FLAG = False
    restart_game = False
    pygame.time.set_timer(NEW_WORM_TIMER, 2000)
    gameOverFont = pygame.font.Font('freesansbold.ttf', 150)
    gameSurf = gameOverFont.render('Game', True, WHITE)
    overSurf = gameOverFont.render('Over', True, WHITE)
    gameRect = gameSurf.get_rect()
    overRect = overSurf.get_rect()
    gameRect.midtop = (WINDOWWIDTH / 2, 10)
    overRect.midtop = (WINDOWWIDTH / 2, gameRect.height + 10 + 25)
    pygame.display.update()

    DISPLAYSURF.blit(gameSurf, gameRect)
    DISPLAYSURF.blit(overSurf, overRect)
    #REQUIREMENT 3:
    drawButton("Start from the beginning", (WINDOWWIDTH // 2, 300), startGame)
    drawButton("Quit", (WINDOWWIDTH // 2, 350), terminate)

    drawPressKeyMsg()
    pygame.display.update()
    pygame.time.wait(500)
    checkForKeyPress() # clear out any key presses in the event queue

    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()

        # Check for button click
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()

        # Rectangles for the buttons
        start_button_rect = pygame.Rect(WINDOWWIDTH // 2 - 100, 250, 200, 50)
        quit_button_rect = pygame.Rect(WINDOWWIDTH // 2 - 50, 300, 100, 50)

        # Check if the mouse is over the buttons
        if start_button_rect.collidepoint(mouse) and click[0] == 1:
            restart_game = True


        if quit_button_rect.collidepoint(mouse) and click[0] == 1:
            terminate()

        if restart_game:
            return

        pygame.event.clear()

def drawScore(score,additional):
    score=score+additional
    scoreSurf = BASICFONT.render('Score: %s' % (score), True, WHITE)
    scoreRect = scoreSurf.get_rect()
    scoreRect.topleft = (WINDOWWIDTH - 120, 10)
    DISPLAYSURF.blit(scoreSurf, scoreRect)


def drawWorm(wormCoords, color):
    for coord in wormCoords:
        x = coord['x'] * CELLSIZE
        y = coord['y'] * CELLSIZE
        wormSegmentRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
        pygame.draw.rect(DISPLAYSURF, color, wormSegmentRect)
        wormInnerSegmentRect = pygame.Rect(x + 4, y + 4, CELLSIZE - 8, CELLSIZE - 8)
        pygame.draw.rect(DISPLAYSURF, color, wormInnerSegmentRect)


def drawApple(coord, color):
    x = coord['x'] * CELLSIZE
    y = coord['y'] * CELLSIZE
    appleRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
    pygame.draw.rect(DISPLAYSURF, color, appleRect)

def drawGrid():
    for x in range(0, WINDOWWIDTH, CELLSIZE): # draw vertical lines
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (x, 0), (x, WINDOWHEIGHT))
    for y in range(0, WINDOWHEIGHT, CELLSIZE): # draw horizontal lines
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (0, y), (WINDOWWIDTH, y))

def drawBlinkingElement(coord):
    x = coord['x'] * CELLSIZE
    y = coord['y'] * CELLSIZE
    elementRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
    pygame.draw.rect(DISPLAYSURF, YELLOW, elementRect)
    pygame.display.update()



def drawButton(text, center, action):
    # Create a button surface and rectangle
    buttonSurf = BASICFONT.render(text, True, WHITE, BLACK)
    buttonRect = buttonSurf.get_rect()
    buttonRect.center = center
    DISPLAYSURF.blit(buttonSurf, buttonRect)

    # Check for button click
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    if buttonRect.left < mouse[0] < buttonRect.right and buttonRect.top < mouse[1] < buttonRect.bottom:
        if click[0] == 1:
            action()

def startGame():
    global additional_points
    additional_points = 0
    runGame()

if __name__ == '__main__':
    main()